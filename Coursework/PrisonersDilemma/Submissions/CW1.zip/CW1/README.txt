Executable files in Release and Debug folders
Source code in PrisonersDilema folder

Program will generate strategies and write them to Strategies folder
It will then read strategies from Strategies folder and write results to TournamentResults

TournamentResults1.txt and TournamentResults2.txt show statistics for tournaments and highlight 
the most successful strategy.
Strategy1.txt through Strategy10.txt show generated files describing prisoner strategies