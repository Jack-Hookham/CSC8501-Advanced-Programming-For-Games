Executable files in Release and Debug folders
Source code in PrisonersDilema folder

Program will generate strategies and write them to Strategies folder
It will then read strategies from Strategies folder and write results to TournamentResults

TournamentResults2.txt shows statics for a tournament and highlights the most successful strategy
Questions.txt shows statistics for a tournament with spy possibilities (0%, 5%, 10%, 15%, 20%)